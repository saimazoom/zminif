
===============================================================

Fonts taken from Czech DTP Program written for Sinclair Spectrum
http://www.worldofspectrum.org/infoseekid.cgi?id=0016682
(public domain)

Converted to fzx format by Einar Saukas

===============================================================

To use this fontpack, first make the library by running "make.bat".  A lib
file will be made which you can copy to your work directory.  Also copy
the header file located here to your work directory.

In your program, simply include the header file, and when compiling, link
against the library file.

The font.c program included here shows how this is done.
