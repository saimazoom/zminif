
===============================================================

FZX fonts by utz

You can use these fonts freely in your non-commercial projects, provided you credit me.
No exclusive reservations for game/demo projects will be accepted, these fonts are for everyone.
If you want an exclusive font for your project, feel free to contact me on WOS.

https://sites.google.com/site/zxgraph/home/utz/fonts

===============================================================

To use this fontpack, first make the library by running "make.bat".  A lib
file will be made which you can copy to your work directory.  Also copy
the header file located here to your work directory.

In your program, simply include the header file, and when compiling, link
against the library file.

The font.c program included here shows how this is done.
